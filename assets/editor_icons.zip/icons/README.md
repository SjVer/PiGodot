# Editor icons

This folder contains all the icons used by Godot editor (except for platform
icons which are located in their respective platform folder).

See [Editor icons](https://docs.godotengine.org/en/latest/contributing/development/editor/creating_icons.html)
in the documentation for details on creating icons for the Godot editor.
